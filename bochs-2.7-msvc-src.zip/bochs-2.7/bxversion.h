/////////////////////////////////////////////////////////////////////////
// This file is checked in as bxversion.h.in.  The configure script
// substitutes variables and creates bxversion.h.
/////////////////////////////////////////////////////////////////////////

#define VERSION       "2.7"
#define VER_SVNFLAG   0
#define REL_STRING    "Built from SVN snapshot on August  1, 2021"
#define REL_TIMESTAMP "Sun Aug  1 10:07:00 CEST 2021"
